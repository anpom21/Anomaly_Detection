demo.dat is the trajectory used in the DMP section
square_move_traj.dat is the trajectory used in the evaluaton section.
This can be changed to fit which graphs you want to generate.

